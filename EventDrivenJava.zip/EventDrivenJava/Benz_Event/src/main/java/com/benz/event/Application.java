package com.benz.event;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.benz.event.service.EventReciver;
import com.benz.event.service.EventSender;

import springfox.documentation.swagger2.annotations.EnableSwagger2;





@SpringBootApplication(scanBasePackages={"com.benz.event.*"})
@EnableSwagger2
public class Application  {
	
	

	public static void main(String[] args) throws Exception {
		
		
		
		SpringApplication.run(Application.class, args);
		EventReciver.eventReciver();
		EventSender.sendEventFunction();
		
	}

	
}
