package com.benz.event.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.benz.event.payload.FuelEventRequest;
import com.benz.event.payload.FuelEventResponse;
import com.benz.event.service.FuelEventService;


@RestController

@RequestMapping("/fuelEvent")
public class FuelEventController {
	
	private static final Logger LOG = LoggerFactory.getLogger(FuelEventController.class);

	@Autowired
	private FuelEventService fuelEventService;

	@PostMapping(value = "/check", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public FuelEventResponse fueleventResponse(@RequestBody FuelEventRequest fuelEventRequest) {
		LOG.debug("inside controller");
		try {
			return fuelEventService.getFuelPriceResponse(fuelEventRequest);
		}

		catch (Exception e) {
			LOG.debug("Exception is " + e);
			return fuelEventService.getFuelPriceFailureResponse();
		}

	}

}
