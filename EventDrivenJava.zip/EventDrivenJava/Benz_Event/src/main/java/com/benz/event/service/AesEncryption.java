
package com.benz.event.service;

import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;


/** need to do encryption and decryption of api request and response using this class*/
public class AesEncryption {

	
	
	private static final String SECURE_KEY = "A1B2C3&^%$OLKI90";
	private static final String PARAM_IV = "TYRF&^JU789%$#I*";

	public static String decrypt(String decryptStr) {
		try {
			IvParameterSpec iv = new IvParameterSpec(PARAM_IV.getBytes(StandardCharsets.UTF_8));
			SecretKeySpec skeySpec = new SecretKeySpec(SECURE_KEY.getBytes(StandardCharsets.UTF_8), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
			byte[] original = cipher.doFinal(DatatypeConverter.parseHexBinary(decryptStr));
			return new String(original);
		} catch (Exception ex) {

		}
		return null;

	}

	public static String encrypt(String value, String canaraIv) {
		try {
			IvParameterSpec iv = new IvParameterSpec(PARAM_IV.getBytes(StandardCharsets.UTF_8));
			SecretKeySpec skeySpec = new SecretKeySpec(SECURE_KEY.getBytes(StandardCharsets.UTF_8), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
			byte[] encrypted = cipher.doFinal(value.getBytes());

			return DatatypeConverter.printHexBinary(encrypted);

		} catch (Exception ex) {

		}
		return null;
	}

}