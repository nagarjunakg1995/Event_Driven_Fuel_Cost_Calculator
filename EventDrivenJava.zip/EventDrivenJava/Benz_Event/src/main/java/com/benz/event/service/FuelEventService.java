package com.benz.event.service;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.benz.event.payload.FuelEventRequest;
import com.benz.event.payload.FuelEventResponse;

@Service
public class FuelEventService {
	private static final Logger LOG = LoggerFactory.getLogger(FuelEventService.class);
private static final String FAILURE="Failure";
	public FuelEventResponse getFuelPriceResponse(FuelEventRequest fuelEventRequest) {

		FuelEventResponse fuelEventResponse = new FuelEventResponse();

		try {

			if (fuelEventRequest.isFuellid()) {

				EventReciver eventReciver = new EventReciver();
				fuelEventResponse = eventReciver.receiveEventResponse(fuelEventRequest);

			} else {

				fuelEventResponse.setTotalAMount("");
				fuelEventResponse.setExternalMsg("fuellid closed");
				fuelEventResponse.setFuelQuantity("");
				fuelEventResponse.setResponseCode(FAILURE);

			}

		} catch (Exception e) {

			LOG.debug("Exception is " + e);
			fuelEventResponse.setTotalAMount("");
			fuelEventResponse.setExternalMsg("Exception");
			fuelEventResponse.setFuelQuantity("");
			fuelEventResponse.setResponseCode(FAILURE);
		}
		return fuelEventResponse;
	}

	public FuelEventResponse getFuelPriceFailureResponse() {

		FuelEventResponse fuelEventResponse = new FuelEventResponse();

		fuelEventResponse.setTotalAMount("");
		fuelEventResponse.setExternalMsg("Exception");
		fuelEventResponse.setFuelQuantity("");
		fuelEventResponse.setResponseCode(FAILURE);

		return fuelEventResponse;
	}

}
