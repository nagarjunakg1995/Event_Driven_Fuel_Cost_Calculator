package com.benz.event.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class EventSender {

	/** event driven sender service */

	private static final String QUEUE_NAME = "Fuel_Price";
	private static final Logger LOG = LoggerFactory.getLogger(EventSender.class);

	public static void sendEventFunction() throws Exception {

		LOG.debug("sendEventFunction");
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("localhost");
		try (Connection connection = factory.newConnection(); Channel channel = connection.createChannel()) {
			channel.queueDeclare(QUEUE_NAME, false, false, false, null);
			Random rand = new Random();
			List<String> city = new ArrayList<>();

			city.add("Bangalore");
			city.add("Kerala");
			city.add("TN");
			int randIndex = rand.nextInt(city.size());

			JSONObject request = new JSONObject();
			request.put("city", city.get(randIndex));
			request.put("fuellid", true);
			String message = request.toString();

			LOG.debug("message in send event function " + message);
			channel.basicPublish("", QUEUE_NAME, null, message.getBytes(StandardCharsets.UTF_8));
			LOG.debug(" [x] Sent '" + message + "'");
		}

		Thread.sleep(120000);
		sendEventFunction();
	}

}