package com.benz.event.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.benz.event.payload.FuelEventRequest;
import com.benz.event.payload.FuelEventResponse;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;


/** event driven receiver service  */


public class EventReciver {

	private static final String QUEUE_NAME = "Fuel_Price";

	private static final Logger LOG = LoggerFactory.getLogger(EventReciver.class);

	private static final String CONTENT_TYPE = "application/json";

	public static void eventReciver() throws IOException, TimeoutException {
		FuelEventResponse fuelEventResponse = new FuelEventResponse();
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("localhost");
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();

		channel.queueDeclare(QUEUE_NAME, false, false, false, null);

		LOG.debug("[*] Waiting for messages. To exit press CTRL+C");

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {
			String message = new String(delivery.getBody(), StandardCharsets.UTF_8);

			LOG.debug("message recived is " + message);

			JSONObject msg = new JSONObject(message);
			LOG.debug("msg is " + msg);

			if (msg.getBoolean("fuellid")) {
				HttpHeaders headers = new HttpHeaders();
				headers.set("Accept", CONTENT_TYPE);
				headers.set("Content-Type", CONTENT_TYPE);

				String restApiUrl = "http://localhost:8080/fuelPrice/check";
				JSONObject requet = new JSONObject();

				requet.put("CITY", msg.getString("city"));

				LOG.debug("requet IS " + requet);

				HttpEntity<String> requestBody = new HttpEntity<>(requet.toString(), headers);
				LOG.debug("api request = " + requestBody.toString());

				RestTemplate restTemplate = new RestTemplate();
				String restApiResponse = restTemplate.postForObject(restApiUrl, requestBody, String.class);
				LOG.debug("rest api restApiResponse = " + restApiResponse);
				JSONObject response = new JSONObject(restApiResponse);
				LOG.debug("rest api responseJson = " + response);

				double price = Double.parseDouble(response.getString("PRICE"));

				/**
				 * assuming that the car can take 1 liter/30 seconds and total time taken is 2
				 * minutes
				 */

				double fuelQuantity = 4;
				double totalAmount = fuelQuantity * price;

				LOG.debug("totalAmount" + totalAmount);

				fuelEventResponse.setTotalAMount(String.valueOf(totalAmount));
				fuelEventResponse.setExternalMsg("");
				fuelEventResponse.setFuelQuantity(String.valueOf(fuelQuantity));
				fuelEventResponse.setResponseCode("Successs");

				LOG.debug("fuelEventResponse is " + fuelEventResponse.toString());

			}

		};
		channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {
		});

	}

	public FuelEventResponse receiveEventResponse(FuelEventRequest fuelEventRequest) {
		FuelEventResponse fuelEventResponse = new FuelEventResponse();
		try {
			LOG.debug("fuelEventRequest is " + fuelEventRequest);
			HttpHeaders headers = new HttpHeaders();
			headers.set("Accept", CONTENT_TYPE);
			headers.set("Content-Type", CONTENT_TYPE);

			String restApiUrl = "http://localhost:8080/fuelPrice/check";
			JSONObject requet = new JSONObject();

			requet.put("CITY", fuelEventRequest.getCity());

			LOG.debug("requet IS " + requet);

			HttpEntity<String> requestBody = new HttpEntity<>(requet.toString(), headers);
			LOG.debug("api request = " + requestBody.toString());

			RestTemplate restTemplate = new RestTemplate();
			String restApiResponse = restTemplate.postForObject(restApiUrl, requestBody, String.class);
			LOG.debug("rest api restApiResponse = " + restApiResponse);
			JSONObject response = new JSONObject(restApiResponse);
			LOG.debug("rest api response = " + response);

			double price = Double.parseDouble(response.getString("PRICE"));

			/**
			 * assuming that the car can take 1 liter/30 seconds and total time taken is 2
			 * minutes
			 */

			double fuelQuantity = 4;
			double totalAmount = fuelQuantity * price;

			LOG.debug("totalAmount" + totalAmount);

			fuelEventResponse.setTotalAMount(String.valueOf(totalAmount));
			fuelEventResponse.setExternalMsg("");
			fuelEventResponse.setFuelQuantity(String.valueOf(fuelQuantity));
			fuelEventResponse.setResponseCode("Success");

			LOG.debug("fuelEventResponse is " + fuelEventResponse.toString());

		} catch (Exception e) {
			LOG.debug("Exception is " + e);
			fuelEventResponse.setTotalAMount("");
			fuelEventResponse.setExternalMsg("Exception");
			fuelEventResponse.setFuelQuantity("");
			fuelEventResponse.setResponseCode("Failure");
		}

		LOG.debug("fuelEventResponse IS " + fuelEventResponse);
		return fuelEventResponse;

	}
}
