package com.benz.event.payload;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FuelEventResponse {

	

	@JsonProperty("fuel_quantity")
    private String fuelQuantity;

	@JsonProperty("total_amount")
	private String totalAMount;
	
	
	@JsonProperty("external_msg")
	private String externalMsg;
	
	
	@JsonProperty("response_code")
	private String responseCode;

	public String getFuelQuantity() {
		return fuelQuantity;
	}

	public void setFuelQuantity(String fuelQuantity) {
		this.fuelQuantity = fuelQuantity;
	}

	public String getTotalAMount() {
		return totalAMount;
	}

	public void setTotalAMount(String totalAMount) {
		this.totalAMount = totalAMount;
	}

	public String getExternalMsg() {
		return externalMsg;
	}

	public void setExternalMsg(String externalMsg) {
		this.externalMsg = externalMsg;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	@Override
	public String toString() {
		return "FuelEventResponse [fuelQuantity=" + fuelQuantity + ", totalAMount=" + totalAMount + ", externalMsg="
				+ externalMsg + ", responseCode=" + responseCode + "]";
	}

	
	
}
