package com.benz.event.payload;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FuelEventRequest {

	@JsonProperty("fuellid")
   private boolean fuellid;

	@JsonProperty("city")
	private String city;

	public boolean isFuellid() {
		return fuellid;
	}

	public void setFuellid(boolean fuellid) {
		this.fuellid = fuellid;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "FuelEventRequest [fuellid=" + fuellid + ", city=" + city + "]";
	}
	
	
	

}
