package com.fuel.price;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import springfox.documentation.swagger2.annotations.EnableSwagger2;




@EnableJpaRepositories(basePackages="com.fuel.price.repository")
@SpringBootApplication(scanBasePackages={"com.fuel.price.*"})
@EnableSwagger2
public class Application  {
	
	

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		 
		SpringApplication.run(Application.class, args);
	}

	
}
