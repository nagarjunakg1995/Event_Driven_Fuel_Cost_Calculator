package com.fuel.price.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fuel.price.entity.TbFuelPrice;



@Repository
public interface FuelPriceRepository extends JpaRepository<TbFuelPrice, String> {
	@Cacheable(key = "FuelPrice")
	TbFuelPrice findByCity(String city);

}
