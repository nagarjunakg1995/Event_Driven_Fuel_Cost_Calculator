package com.fuel.price.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_fuel_price_check")
public class TbFuelPrice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "city")
	private String city;

	@Column(name = "price")
	private String price;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "TbFuelPrice [city=" + city + ", price=" + price + "]";
	}

	
	
	
}
