package com.fuel.price.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fuel.price.payload.FuelPriceRequest;
import com.fuel.price.payload.FuelPriceResponse;
import com.fuel.price.service.FuelPriceService;

@RestController

@RequestMapping("/fuelPrice")

public class FuelPriceController {
	

	@Autowired
	private FuelPriceService fuelPriceService;

	@PostMapping(value = "/check", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public FuelPriceResponse addCountry(@RequestBody FuelPriceRequest tbDbtpAosMasterRequest) {
		
		try {
			return fuelPriceService.getFuelPriceResponse(tbDbtpAosMasterRequest);
		}

		catch (Exception e) {
			
			return fuelPriceService.getFuelPriceFailureResponse();
		}

	}

}
