package com.fuel.price.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fuel.price.entity.TbFuelPrice;
import com.fuel.price.payload.FuelPriceRequest;
import com.fuel.price.payload.FuelPriceResponse;
import com.fuel.price.repository.FuelPriceRepository;

@Service
public class FuelPriceService {

	private FuelPriceResponse fuelPriceResponse = new FuelPriceResponse();

	@Autowired
	private FuelPriceRepository fuelPriceRepository;

	private static final String FAILURE = "FAILURE";

	public FuelPriceResponse getFuelPriceResponse(FuelPriceRequest fuelPriceRequest) {
		TbFuelPrice tbFuelPrice = null;
		try {

			String city = fuelPriceRequest.getcity();
			String price = "";

			tbFuelPrice = fuelPriceRepository.findByCity(city);

			if (tbFuelPrice != null && (Integer.parseInt(tbFuelPrice.getPrice()) > 0)) {
				price = tbFuelPrice.getPrice();

				fuelPriceResponse.setPrice(price);
				fuelPriceResponse.setStatus("SUCCESS");

			} else {

				fuelPriceResponse.setPrice(price);
				fuelPriceResponse.setStatus(FAILURE);
			}

		}

		catch (Exception e) {

			fuelPriceResponse.setPrice("");
			fuelPriceResponse.setStatus(FAILURE);

		}

		return fuelPriceResponse;
	}

	public FuelPriceResponse getFuelPriceFailureResponse() {
		fuelPriceResponse.setPrice("");
		fuelPriceResponse.setStatus(FAILURE);
		return fuelPriceResponse;
	}
}
