package com.fuel.price.payload;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class FuelPriceRequest {

	@JsonProperty("CITY")
	@ApiModelProperty(example = "Bangalore")
	private String city;

	public String getcity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "FuelPriceRequest [city=" + city + "]";
	}

}