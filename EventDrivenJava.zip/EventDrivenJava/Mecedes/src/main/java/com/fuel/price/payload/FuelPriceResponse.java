package com.fuel.price.payload;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class FuelPriceResponse {

	@JsonProperty("PRICE")
	@ApiModelProperty(example = "95")
	private String price;

	@JsonProperty("STATUS")
	@ApiModelProperty(example = "Success")
	private String status;
	
	public String getPrice() {
		return price;
	}
	
	

	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public void setPrice(String price) {
		this.price = price;
	}



	@Override
	public String toString() {
		return "FuelPriceResponse [price=" + price + ", status=" + status + "]";
	}

	
}
